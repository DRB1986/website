official GIT documentation
https://github.com/DRB1986/website